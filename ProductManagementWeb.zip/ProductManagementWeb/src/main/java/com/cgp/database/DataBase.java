package com.cgp.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cgp.domain.Category;
import com.cgp.domain.Discount;
import com.cgp.domain.Product;
import com.cgp.domain.SubCategory;
import com.cgp.domain.Supplier;
 
 
 
 
 

public class DataBase {
	Connection con = null;
	public boolean createProduct(Product product)
	{
		int no = 0;
		ResultSet rs = null;
		PreparedStatement psmt = null;
		PreparedStatement psmt1 = null;
		int proId = 0;
		String sql = "insert into product(product_Name,description,ManufacturingDate,ExpiryDate,MaximumRetailPrice,category_Id,sub_category_Id,supplier_Id, quantity) values(?,?,?,?,?,?,?,?,?)";
		try {
			  con = getSQLConnection();
			  psmt=con.prepareStatement(sql);
			  java.sql.Date sqlMfd = new java.sql.Date(product.getManufacturing_date().getTime());
			  java.sql.Date sqlExp = new java.sql.Date(product.getExpiry_date().getTime());
			  psmt.setString(1, product.getProductName());
			  psmt.setString(2, product.getDescription());
			  psmt.setDate(3, sqlMfd);
			  psmt.setDate(4, sqlExp);
			  psmt.setDouble(5, product.getMax_retail_price());
			  psmt.setInt(6, product.getCategory().getCategory_Id());
			  psmt.setInt(7, product.getSubCategory().getSub_category_Id());
			  psmt.setInt(8, product.getSupplier().getSupplierId());
			  psmt.setInt(9, product.getQuantity());
			 no= psmt.executeUpdate();
			  rs = getPreparedStatement("select * from product").executeQuery();
				while (rs.next()) {
					proId = rs.getInt(1);
				}
				psmt1 = getPreparedStatement("insert into product_discount values(?,?)");
				for (Discount d : product.getDiscounts()) {
					psmt1.setInt(1, proId);
					psmt1.setInt(2, d.getDiscountId());
					System.out.println(psmt1.executeUpdate());
				}
		}catch (SQLException e) 
			{
				e.printStackTrace();
			}finally{
		
					try {
						psmt1.close();
						psmt.close();
						
						con.close();
						} catch (SQLException e) {
			
								e.printStackTrace();
							}
					}
			if(no>0)
				return true;
			else
				return false;
	}
	
	
	
	
	public List<Category> getAllCategory() {
		List<Category> categories = new ArrayList<Category>();
		Category category = null;
		ResultSet rs = null;
		try {
			rs = getPreparedStatement("select * from category").executeQuery();

			while (rs.next()) {
				category = new Category();
				category.setCategory_Id(rs.getInt(1));
				category.setCategory_Name(rs.getString(2));
				category.setDescription(rs.getString(3));
				categories.add(category);
			}
			 
		} catch (SQLException e) {
			e.printStackTrace();
		}

		categories.add(category);
		return categories;
	}
	public List<SubCategory> getAllSubCategory() {
		List<SubCategory> subCategories = new ArrayList<SubCategory>();
		List<Category> categories = getAllCategory();
		Category category = null;
		SubCategory subCategory = null;
		ResultSet rs = null;
		try {
			rs = getPreparedStatement("select * from subcategory").executeQuery();
			while (rs.next()) {
				category = new Category();
				subCategory = new SubCategory();
				subCategory.setSub_category_Id(rs.getInt(1));
				subCategory.setSub_category_Name(rs.getString(2));
				int catId = rs.getInt(3);
				for (Category cat : categories)
					if (cat.getCategory_Id() == catId)
						category = cat;
				subCategory.setCategory(category);
				subCategories.add(subCategory);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return subCategories;

	}
	
	public List<Supplier> getAllSuppliers() {
		List<Supplier> suppliers = new ArrayList<Supplier>();
		Supplier supplier = null;
		ResultSet rs = null;
		try {
			rs = getPreparedStatement("select * from supplier").executeQuery();
			while (rs.next()) {
				supplier = new Supplier();
				supplier.setSupplierId(rs.getInt(1));
				supplier.setFirstName(rs.getString(2));
				supplier.setLastName(rs.getString(3));
				supplier.setAddress(rs.getString(4));
				supplier.setCity(rs.getString(5));
				supplier.setState(rs.getString(6));
				supplier.setPincode(rs.getString(7));
				supplier.setContactno(rs.getString(8));
				suppliers.add(supplier);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return suppliers;
	}
	
	public List<Discount> getAllDiscounts() {
		List<Discount> discounts = new ArrayList<Discount>();
		Discount discount = null;
		ResultSet rs = null;
		try {
			rs = getPreparedStatement("select * from discount").executeQuery();
			while (rs.next()) {
				discount = new Discount();
				discount.setDiscountId(rs.getInt(1));
				discount.setDiscountName(rs.getString(2));
				discount.setDescription(rs.getString(3));
				discount.setDiscount_percentage(rs.getDouble(4));
				discount.setValidThru(rs.getDate(5));
				discounts.add(discount);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return discounts;
	}
	public List<Product> getAllProducts() {
		List<Product> listProducts = new ArrayList<Product>();
		Product product = null;
		Category category = null;
		SubCategory subcategory = null;
		Supplier supplier = null;
		Discount discount = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		try {
			rs = getPreparedStatement("select * from product").executeQuery();
			while (rs.next()) 
			{
				product = new Product();
				product.setProductId(rs.getInt(1));
				product.setProductName(rs.getString(2));
				product.setDescription(rs.getString(3));
				product.setManufacturing_date(rs.getDate(4));
				product.setExpiry_date(rs.getDate(5));
				product.setMax_retail_price(rs.getDouble(6));
				int catId = rs.getInt(7);
				//System.out.println("RS:" +rs.getInt(8));
				for (Category cat : getAllCategory()) {
					if (cat.getCategory_Id() == catId) {
						 category = cat;
						break;
					}
				}
				
				product.setCategory(category);

				// product.setCategory(category);

				int subcatId = rs.getInt(8);
				for (SubCategory subcat : getAllSubCategory()) {
					if (subcat.getSub_category_Id() == subcatId) {
						subcategory = subcat;
						break;
					}

				}

				product.setSubCategory(subcategory);

				int supId = rs.getInt(9);
				for (Supplier supply : getAllSuppliers()) {
					if (supply.getSupplierId() == supId) {
						supplier = supply;
						break;
					}

				}

				product.setSupplier(supplier);
				
				product.setQuantity(rs.getInt(10));
				pst = getPreparedStatement("select * from product_discount where product_Id=?");
				pst.setInt(1, product.getProductId());
			ResultSet	rs1 = pst.executeQuery();
				//Discount disount = null;
				List<Discount> discountList = null;
				while (rs1.next()) {
					discountList = new ArrayList<Discount>();
					int d = rs1.getInt(2);

					for (Discount dis : getAllDiscounts()) {

						if (d == dis.getDiscountId()) {
							//discount = dis; 
							discountList.add(dis);
						}
					}
				 
				}
				product.setDiscounts(discountList);
				listProducts.add(product);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				 con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return listProducts;
	}

 
 public PreparedStatement getPreparedStatement(String query) {
		PreparedStatement psmt = null;
		try {
			psmt = getSQLConnection().prepareStatement(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return psmt;
	}
 
	public Connection getSQLConnection(){
		 
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/classroom","root","India123");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
		
	}
}
