package com.cgp.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cgp.database.DataBase;
import com.cgp.domain.SubCategory;
import com.cgp.domain.Supplier;
import com.google.gson.Gson;

 
public class JsonConvertForSupplier extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		 PrintWriter out=response.getWriter();
		
		 DataBase db=new DataBase();
		 List<Supplier> supplieres=db.getAllSuppliers();
		 Gson myJson=new Gson();
		 String Supplier=myJson.toJson(supplieres);
		 out.println(Supplier);
	}

}
