package com.cgp.view;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cgp.database.DataBase;
import com.cgp.domain.Category;
import com.cgp.domain.Discount;
import com.cgp.domain.Product;
import com.cgp.domain.SubCategory;
import com.cgp.domain.Supplier;

public class ProductInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		SimpleDateFormat sdf=new SimpleDateFormat("YYYY-MM-dd");
		String pName = request.getParameter("pname");
		String pDesc = request.getParameter("pdescription");
		String pMfd = request.getParameter("pmfd");
		String pExp = request.getParameter("pexp");
		String pMrp = request.getParameter("pmrp");
		String pQty = request.getParameter("pqty");
		String pRating = request.getParameter("prating");
		String pCat = request.getParameter("pCategory");
		String psubCat = request.getParameter("pSubCategory");
		String pSupply = request.getParameter("pSupply");
		 
		
		   Product product = new Product();
		   product.setProductName(pName);
		   product.setDescription(pDesc);
		   try {
			product.setManufacturing_date(sdf.parse(pMfd));
			   product.setExpiry_date(sdf.parse(pExp));
		} catch (ParseException e) {
		
			e.printStackTrace();
		}
		
		   product.setMax_retail_price(Double.parseDouble(pMrp));
		   product.setQuantity(Integer.parseInt(pQty));
		   product.setRatings(Float.parseFloat(pRating));
		  
		DataBase db = new DataBase();
		Category cat=new Category();
		cat.setCategory_Id(Integer.parseInt(pCat));
		product.setCategory(cat);
		// List All SubCategory
		SubCategory sub = null;
		List<SubCategory> listSubCategory = db.getAllSubCategory();
		for (SubCategory subCategory : listSubCategory) {
			if (subCategory.getSub_category_Id() == Integer.parseInt(psubCat))
				sub = subCategory;
			product.setSubCategory(sub);
		}
		// List All Supplier
		Supplier sup = null;
		List<Supplier> listSupplier = db.getAllSuppliers();
		for (Supplier supplier : listSupplier) {
			if (supplier.getSupplierId() == Integer.parseInt(pSupply))
				sup = supplier;
			product.setSupplier(sup);
		}

		String[] pDiscountIds=request.getParameterValues("pdiscount");
		List<Discount> appliedDiscounts = new ArrayList<>();
		for(Discount discount:db.getAllDiscounts())
			for(String iD: pDiscountIds)
				if(Integer.parseInt(iD)==discount.getDiscountId())
					appliedDiscounts.add(discount);
		
		product.setDiscounts(appliedDiscounts);
		
	boolean flag=db.createProduct(product);
	RequestDispatcher rd=request.getRequestDispatcher("www.google.co.in");
	if(flag==true)
	{
		rd.forward(request, response);
	}
	else
	{
		System.out.println("error");
	}
		
		

	}

}
