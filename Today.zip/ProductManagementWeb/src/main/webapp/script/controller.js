 app.controller("myCtrl", function($scope, $http) {
		$scope.getProduts = function() {
			var url = 'http://localhost:8080/ProductManagementWeb/JsonConvertForProduct';
			$http.get(url).success(function(response) {
				
				$scope.products = response;
			}).error(function(msg) {
				$scope.products = msg;
			});
		};

		$scope.getCategories = function() {
			var url = 'http://localhost:8080/ProductManagementWeb/JsonConvert';
			$http.get(url).success(function(response) {
				$scope.cats = response;
			}).error(function(msg) {
				$scope.cats = msg;
			});

		};
		
		$scope.getSubCategories = function() {
			var url = 'http://localhost:8080/ProductManagementWeb/JsonConvertForSubCategory';
			$http.get(url).success(function(response) {
				$scope.subcats = response;
			}).error(function(msg) {
				$scope.cats = msg;
			});

		};
		
		$scope.getSuppliers = function() {
			var url = 'http://localhost:8080/ProductManagementWeb/JsonConvertForSupplier';
			$http.get(url).success(function(response) {
				$scope.supplier = response;
			}).error(function(msg) {
				$scope.supplier = msg;
			});

		};
		
		$scope.searchMethod = function() {
			var url = 'http://localhost:8080/ProductManagementWeb/JsonControler';
			$http.get(url).success(function(response) {
				$scope.search = response;
			}).error(function(msg) {
				$scope.search = msg;
			});

		};
		
		$scope.getDiscount = function() {
			var url = 'http://localhost:8080/ProductManagementWeb/JsonConvertForDiscount';
			$http.get(url).success(function(response) {
				$scope.discount = response;
			}).error(function(msg) {
				$scope.success = msg;
			});

		};
	});