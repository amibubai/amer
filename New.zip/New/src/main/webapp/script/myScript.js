function displaySalary(){
	
	var sal=empForm.empSalary.value;
	//alert(sal);
	document.getElementById('divSal').innerHTML='<b>'+sal+'</b>';
	 
}

function validate()
{
	var enm = document.getElementById("fname").value;
	if (enm == '') {
		document.getElementById('enm').innerHTML = '*Please enter Employee name.';
		return 

	}

	else  
		document.getElementById('enm').innerHTML = '';
}