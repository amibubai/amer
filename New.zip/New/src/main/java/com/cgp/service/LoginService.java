package com.cgp.service;

import java.util.List;

import com.cgp.domain.Employee;
import com.cgp.domain.Login;

public interface LoginService {
	
	public boolean isValidUser(Login login);

	public boolean createEmployee(Employee employee);

	public boolean deleteEmployee(int empId);

	 
	public List<Employee> getAllEmployees();
 
	public Employee searchEmployee(int empId);
	public boolean updateEmployee(Employee employee);

}
