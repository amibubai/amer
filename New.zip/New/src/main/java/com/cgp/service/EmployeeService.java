package com.cgp.service;

import com.cgp.domain.Employee;

public interface EmployeeService {
	public int insert(Employee emp);
}
