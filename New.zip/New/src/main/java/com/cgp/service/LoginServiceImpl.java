package com.cgp.service;

 

import java.util.List;

import com.cgp.dao.LoginDao;
import com.cgp.dao.LoginDaoImpl;
import com.cgp.domain.Employee;
import com.cgp.domain.Login;

public class LoginServiceImpl implements LoginService{

	LoginDao loginDao=new LoginDaoImpl();
	
 

 


	@Override
	public boolean isValidUser(Login login) {
		 return loginDao.isValidUser(login);
	}



	@Override
	public boolean createEmployee(Employee employee) {
		 return loginDao.createEmployee(employee);
	}



	@Override
	public List<Employee> getAllEmployees() {
		
		return loginDao.getAllEmployees();
	}

	@Override
	public boolean deleteEmployee(int empId) {
		
		return loginDao.deleteEmployee(empId);
	}

	@Override
	public Employee searchEmployee(int empId) {
		
		return loginDao.searchEmployee(empId);
	}

}
