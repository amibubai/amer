package com.cgp.main;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

 

public class MyTagHandler extends SimpleTagSupport{
private String msg;
	
	
	

	public void setMsg(String msg) {
		this.msg = msg;
	}



	 
	
	 
 
	public void doTag() throws JspException, IOException {
		JspWriter out=getJspContext().getOut();
		 
		
		StringWriter str=new StringWriter();
		getJspBody().invoke(str);
		
		if(msg==null)
			out.println( str + "  <b>"+" " +"</b>");
		else{
			 
			out.println( str + "  <b>"+msg +"</b>");
		}
	}

}
