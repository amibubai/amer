package com.cgp.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cgp.domain.Department;
import com.cgp.domain.Employee;
import com.cgp.service.LoginService;
import com.cgp.service.LoginServiceImpl;

 
public class UpdateSucessful extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
  	LoginService loginService=new LoginServiceImpl();
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		String empId=request.getParameter("empId");
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String sal=request.getParameter("empSalary");
		String dob=request.getParameter("empDob");
		String doj=request.getParameter("empDoj");
		String gen=request.getParameter("gender");
		String dept=request.getParameter("empDepart");
		String address=request.getParameter("empAddress");
		String[] qualify=request.getParameterValues("chkQualification");
		String qualification="";
		for(String str:qualify)
			qualification+=str+",";
		
		Employee employee=new Employee();
		
		employee.setEmpId(Integer.parseInt(empId));
		employee.setFirstName(fname);
		employee.setLastName(lname);
		 employee.setSalary(Double.parseDouble(sal));
		 SimpleDateFormat myFormat=new SimpleDateFormat("yyyy-MM-dd");
		 Date eDoj=null;
		Date eDob=null;
		try {
			eDoj=myFormat.parse(doj);
			eDob=myFormat.parse(dob);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		employee.setEmpDob(eDob);//dd-MMM-yyyy
		employee.setEmpDoj(eDoj);//dd-MMM-yyyy
		employee.setQualification(qualification);
		 employee.setGender(gen);
		employee.setAddress(address);
		Department department=new Department();
		department.setDepartmentId(Integer.parseInt(dept));
		employee.setDepartment(department);
		
		boolean flag=loginService.updateEmployee(employee);
		System.out.println("#######"+flag);
		if(flag)
			response.sendRedirect("UpdateEmpServlet");
		else
			response.sendRedirect("pages/errorPage.html");
		
	}

		
		 
			
 

	}
 
 



 