package com.cgp.main;

 

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 

import com.cgp.dao.LoginDao;
import com.cgp.dao.LoginDaoImpl;
import com.cgp.domain.Department;
import com.cgp.domain.Employee;
 
public class UpdateEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();

		
		int empId=Integer.parseInt(request.getParameter("empId"));
		
		LoginDao loginService=new LoginDaoImpl();
		 Employee emp=loginService.searchEmployee(empId);
		 
		 
		int empid=emp.getEmpId();
		out.println("<html><head><title></title><script type='text/javascript' src='../script/myScript.js'></script></head>"
				+ "<body>"
				+ "<form  action='UpdateSucessful?empId="+empid+"' method='post'>");
		out.println("<h1 align='center'>Update Emplyee</h1><hr>");	
		
		
		out.println("<table style='margin-left:200px;border:1px solid black;'>"
				+ "<tr>"
				+ "<td>Employee Id</td>"
				+ "<td>"+emp.getEmpId()+"</td>" 
				+ "</tr>"
				+ "<tr>"
				+ "<td>FirstName</td>"
				+ "<td><input type='text' name='fname' value='" + emp.getFirstName()+"' size='20'>"
				+ "</tr>"
				+ "<tr>"
				+ "<td>LastName</td>"
				+ "<td><input type='text' name='lname' value='" + emp.getLastName()+"' size='20'>"
				+ "</tr>"
				+ "<tr>"
				+ "<td>Salary</td>"
				+ "<td><input type='range' name='empSalary' value='" + emp.getSalary()+"' size='20'>"
				+ "</tr>"
				+ "<tr>"
				+ "<td>Date Of Birth</td>"
				+ "<td><input type='date' name='empDob'  value='" + emp.getEmpDob()+"' size='20'>"
				+ "</tr>"
				+ "<tr>"
				+ "<td>Date Of Joining</td>"
				+ "<td><input type='date' name='empDoj'  value='" + emp.getEmpDoj()+"' size='20'>"
				+ "</tr>"
				+ "<tr>");
				String str=emp.getQualification();
				String[] qualifications=str.split(",");
				List<String> list1=new ArrayList<>();
				for(String q:qualifications)
					list1.add(q);
				System.out.println(list1);
				out.print("<td>Qualification:</td>");
				if(list1.contains("BE"))
					out.println("<td><input type='checkbox' name='chkQualification'  checked='checked' value='BE'>BE</td>");
				else
					out.println("<td><input type='checkbox' name='chkQualification'  value='BE'>BE</td>");
			 if(list1.contains("ME"))
					out.println("<td><input type='checkbox' name='chkQualification' checked='checked' value='ME'>ME</td>");
				else
					out.println("<td><input type='checkbox'  name='chkQualification' value='ME'>ME</td>");
			 
			 if(list1.contains("MBA"))
					out.println("<td><input type='checkbox' name='chkQualification' checked='checked' value='MBA'>MBA</td>");
				else
					out.println("<td><input type='checkbox'  name='chkQualification' value='MBA'>MBA</td>");
				
			 if(list1.contains("BTECH"))
					out.println("<td><input type='checkbox' name='chkQualification' checked='checked' value='BTECH'>BTECH</td>");
				else
					out.println("<td><input type='checkbox' name='chkQualification'  value='BTECH'>BTECH</td>");
			 
			     out.println("<tr><td>Gender:</td>");
				  String radio=emp.getGender();
				  if(radio.equals("Male"))
				  {
					  out.println("<td><input type='radio' name='gender' value='Male' checked='checked'>Male</td>");
					  out.println("<td><input type='radio' name='gender' value='Female'>Female</td></tr>");
				  }  
				  else
				  {
					  out.println("<td><input type='radio' name='gender' value='Male' checked='unchecked'>Male</td>");
					  out.println("<td><input type='radio' name='gender' value='Female' checked='checked'>Female</td></tr>");
				  }
				   
				  out.println("<tr><td> Department </td></tr>");
				int dept=emp.getDepartment().getDepartmentId();
				 if(dept==1)
					 out.println("<tr><td><select name='empDepart'><option value='1'selected='selected'>Sales</option><option value='2'>Purchase</option><option value='3'>Finance</option><option value='4'>Marketing</option></select></td></tr>");
				  
				 if(dept==2)
					 out.println("<tr><td><select name='empDepart'><option value='1'>Sales</option><option value='2' selected='selected'>Purchase</option><option value='3'>Finance</option><option value='4'>Marketing</option></select></td></tr>");
				 
				  
				 if(dept==3)
					 out.println("<tr><td><select name='empDepart'><option value='1'>Sales</option><option value='2' >Purchase</option><option value='3' selected='selected'>Finance</option><option value='4'>Marketing</option></select></td></tr>");
				 
				 
				 if(dept==4)
					 out.println("<tr><td><select name='empDepart'><option value='1'>Sales</option><option value='2' >Purchase</option><option value='3' selected='selected'>Finance</option><option value='4'selected='selected'>Marketing</option></select></td></tr>");
				 
				 
				  out.println(" <tr><td>Address</td><td><textarea rows='5' cols='20' name='empAddress' ' size='20'>"+emp.getAddress()+"</textarea></td>");
			 
				  
				out.println( "<tr>"
				+ "<td></td>"
				+ "<td><input type='submit' name='update' value='Update'></td>"
				+ "</tr>");
				out.println( "</table></form></body></html>");
	
	}

}
