package com.cgp.main;

 

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 

import com.cgp.dao.LoginDao;
import com.cgp.dao.LoginDaoImpl;
import com.cgp.domain.Employee;
 
public class UpdateEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		int empId=Integer.parseInt(request.getParameter("employeeId"));
		
		LoginDao loginService=new LoginDaoImpl();
		 Employee emp=loginService.searchEmployee(empId);
		 
		 
		
		out.println("<html><head><title>UpdateEmployee</title></head>"
				+ "<body>"
				+ "<form method='post' action='#' >");
		
		out.println("<h1 align='center'>Update Emplyee</h1><hr>");	
		
		
		out.println("<table style='margin-left:200px;border:1px solid black;'>"
				+ "<tr>"
				+ "<td>Employee Id</td>"
				+ "<td>"+emp.getEmpId()+"</td>" 
				+ "</tr>"
				+ "<tr>"
				+ "<td>FirstName</td>"
				+ "<td><input type='text' name='fname' value='" + emp.getFirstName()+"' size='20'>"
				+ "</tr>"
				+ "<tr>"
				+ "<td>LastName</td>"
				+ "<td><input type='text' name='lname' value='" + emp.getLastName()+"' size='20'>"
				+ "</tr>"
				+ "<tr>"
				+ "<td>Salary</td>"
				+ "<td><input type='range' name='empSalary' value='" + emp.getSalary()+"' size='20'>"
				+ "</tr>"
				+ "<tr>"
				+ "<td>Date Of Birth</td>"
				+ "<td><input type='date' name='empDob'  value='" + emp.getEmpDob()+"' size='20'>"
				+ "</tr>"
				+ "<tr>"
				+ "<td>Date Of Joining</td>"
				+ "<td><input type='date' name='empDoj'  value='" + emp.getEmpDoj()+"' size='20'>"
				+ "</tr>");
				  
				out.println( "<tr>"
				+ "<td></td>"
				+ "<td><input type='submit' name='update' value='Update'>"
				+ "</tr>");
		
		
				
				
				out.println( "</table></form></body></html>");
		
		
		
		
	
	}

}
