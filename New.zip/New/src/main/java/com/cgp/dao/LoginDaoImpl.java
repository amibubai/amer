package com.cgp.dao;

 

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

 
import com.cgp.domain.Department;
import com.cgp.domain.Employee;
import com.cgp.domain.Login;

 

public class LoginDaoImpl implements LoginDao {

	 

	
	public Connection getSQLConnection(){
		Connection conn=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/classroom","root","India123");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}


	@SuppressWarnings("finally")
	 
	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> employees=new ArrayList<>();
		Connection conn=null;
		PreparedStatement pst=null;
		
		String sql="select * from cgpemployee";
		
		try{
		conn=getSQLConnection();
		pst=conn.prepareStatement(sql);
		ResultSet rs=pst.executeQuery();
		
		while(rs.next()){
			Employee emp=new Employee();
			
			emp.setEmpId(rs.getInt(1));
			emp.setFirstName(rs.getString(2));
			emp.setLastName(rs.getString(3));
			emp.setSalary(rs.getDouble(4));
			emp.setEmpDob(rs.getDate(5));
			emp.setEmpDoj(rs.getDate(6));
			Department depart=new Department();
			depart.setDepartmentId(rs.getInt(7));
			emp.setDepartment(depart);
			emp.setEmail(rs.getString(8));
			emp.setQualification(rs.getString(9));
			emp.setGender(rs.getString(10));
			emp.setAddress(rs.getString(11));
			employees.add(emp);
			
		}
		
	
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				pst.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return employees;
	}


	@SuppressWarnings("finally")
	@Override
	public boolean deleteEmployee(int empId) {
		boolean flag=false;
		Connection conn=null;
		PreparedStatement pst=null;
		
		String sql="delete from cgpemployee where empid=?";
		
		try{
			
			conn=getSQLConnection();
			pst=conn.prepareStatement(sql);
			pst.setInt(1, empId);
			
			int count=pst.executeUpdate();
			
			if(count>0)
				flag=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				pst.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return flag;
		}
		
		//return flag;
	}


 
	@Override
	public boolean isValidUser(Login login) {
		boolean flag=false;
		String sql="select * from login where userName=? and userPassword=?";
		try {
			PreparedStatement pst=getSQLConnection().prepareStatement(sql);
			
			pst.setString(1, login.getUserName());
			pst.setString(2, login.getUserPwd());
			
			ResultSet rs=pst.executeQuery();
			if(rs.next())
				flag=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return flag;
	}


	@Override
	public boolean createEmployee(Employee employee) {
		boolean flag=false;
		Connection conn=null;
		PreparedStatement pst=null;
		String sql="insert into cgpemployee(empFname,empLname,salary,dob,doj,dept,email,qualification,gender,address) "
												+ "values (?,?,?,?,?,?,?,?,?,?) ";
		try {
			conn=getSQLConnection();
			pst=conn.prepareStatement(sql);
			
			
			pst.setString(1, employee.getFirstName());
			pst.setString(2, employee.getLastName());
			pst.setDouble(3, employee.getSalary());
			pst.setDate(4, new Date(employee.getEmpDob().getTime()));
			pst.setDate(5, new Date(employee.getEmpDoj().getTime()));
			pst.setInt(6, employee.getDepartment().getDepartmentId());
			pst.setString(7, employee.getEmail());
			pst.setString(8, employee.getQualification());
			pst.setString(9, employee.getGender());
			pst.setString(10, employee.getAddress());
			
			
			int count=pst.executeUpdate();
			
			if(count>0){
				flag=true;
				System.out.println("Record Inserted");
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally{
			
			try {
				
				pst.close();
				conn.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			return flag;
		}
	}


	@Override
	public Employee searchEmployee(int empId) {
Employee emp=new Employee();
		
		Connection conn=null;
		PreparedStatement pst=null;
		
		String sql="select * from cgpemployee where empid=?";
		
		try{
		conn=getSQLConnection();
		pst=conn.prepareStatement(sql);
		
		pst.setInt(1, empId);
		
		ResultSet rs=pst.executeQuery();
		if(rs.next()){
			emp.setEmpId(rs.getInt(1));
			emp.setFirstName(rs.getString(2));
			emp.setLastName(rs.getString(3));
			emp.setSalary(rs.getDouble(4));
			emp.setEmpDob(rs.getDate(5));
			emp.setEmpDoj(rs.getDate(6));
			Department depart=new Department();
			depart.setDepartmentId(rs.getInt(7));
			emp.setDepartment(depart);
			
			emp.setEmail(rs.getString(8));
			
			emp.setQualification(rs.getString(9));
			emp.setGender(rs.getString(10));
			emp.setAddress(rs.getString(11));
			
		}else
			emp=null;
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				pst.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		return emp;
	}
	
}
