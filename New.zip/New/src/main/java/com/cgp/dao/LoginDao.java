package com.cgp.dao;

import java.util.List;

import com.cgp.domain.Employee;
import com.cgp.domain.Login;

 

public interface LoginDao {
	public boolean isValidUser(Login login);
	
	public boolean createEmployee(Employee employee);
	
	public List<Employee> getAllEmployees();
	
	public boolean deleteEmployee(int empId);
	
	public Employee searchEmployee(int empId);
}
