app.value("count",50);
app.constant("compName","Capgemini Consulting Services");

app.factory("myFactory",function(){
	//console.log("Factory:" +compName );
	return "Hello!";
	
});


app.service("myService",function(){
	
	this.qube=function(num){
	return num*num*num;
	}
	
	this.fullName=function(fName,lName){
		return fName+" " +lName;
	}
});



app.factory("myFactory",function(){
	
	return "Hello!";
	
});


app.controller("myCtrl",function($scope,count,myFactory,myService,compName){
	
	$scope.num=count+100;
	$scope.myVal=myService.qube(count);
	console.log(myFactory);
	$scope.myName=myService.fullName('tom','Jerry');
	console.log(compName);
	compName="TCS";
	console.log(compName);
	
	//console.log("Count:" + count);
	
});

