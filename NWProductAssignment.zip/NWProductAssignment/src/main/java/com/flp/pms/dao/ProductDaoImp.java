package com.flp.pms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;

public class ProductDaoImp implements IProductDao {
	Connection con = null;

	public List<Category> getAllCategory() {
		List<Category> categories = new ArrayList<Category>();
		Category category = null;
		ResultSet rs = null;
		try {
			rs = getPreparedStatement("select * from category").executeQuery();

			while (rs.next()) {
				category = new Category();
				category.setCategory_Id(rs.getInt(1));
				category.setCategory_Name(rs.getString(2));
				category.setDescription(rs.getString(3));
				categories.add(category);
			}
			 
		} catch (SQLException e) {
			e.printStackTrace();
		}

		categories.add(category);
		return categories;
	}

	public List<SubCategory> getAllSubCategory() {
		List<SubCategory> subCategories = new ArrayList<SubCategory>();
		List<Category> categories = getAllCategory();
		Category category = null;
		SubCategory subCategory = null;
		ResultSet rs = null;
		try {
			rs = getPreparedStatement("select * from subcategory").executeQuery();
			while (rs.next()) {
				category = new Category();
				subCategory = new SubCategory();
				subCategory.setSub_category_Id(rs.getInt(1));
				subCategory.setSub_category_Name(rs.getString(2));
				int catId = rs.getInt(3);
				for (Category cat : categories)
					if (cat.getCategory_Id() == catId)
						category = cat;
				subCategory.setCategory(category);
				subCategories.add(subCategory);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return subCategories;

	}

	public List<Supplier> getAllSuppliers() {
		List<Supplier> suppliers = new ArrayList<Supplier>();
		Supplier supplier = null;
		ResultSet rs = null;
		try {
			rs = getPreparedStatement("select * from supplier").executeQuery();
			while (rs.next()) {
				supplier = new Supplier();
				supplier.setSupplierId(rs.getInt(1));
				supplier.setFirstName(rs.getString(2));
				supplier.setLastName(rs.getString(3));
				supplier.setAddress(rs.getString(4));
				supplier.setCity(rs.getString(5));
				supplier.setState(rs.getString(6));
				supplier.setPincode(rs.getString(7));
				supplier.setContactno(rs.getString(8));
				suppliers.add(supplier);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return suppliers;
	}

	public List<Discount> getAllDiscounts() {
		List<Discount> discounts = new ArrayList<Discount>();
		Discount discount = null;
		ResultSet rs = null;
		try {
			rs = getPreparedStatement("select * from discount").executeQuery();
			while (rs.next()) {
				discount = new Discount();
				discount.setDiscountId(rs.getInt(1));
				discount.setDiscountName(rs.getString(2));
				discount.setDescription(rs.getString(3));
				discount.setDiscount_percentage(rs.getDouble(4));
				discount.setValidThru(rs.getDate(5));
				discounts.add(discount);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return discounts;
	}

	public boolean addProduct(Product product) {
		int no = 0;
		ResultSet rs = null;
		PreparedStatement pst = null;
		int proId = 0;
		String sql = "insert into product(product_Name,description,ManufacturingDate,ExpiryDate,MaximumRetailPrice,category_Id,sub_category_Id,supplier_Id, quantity) values(?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement psmt = getConnection().prepareStatement(sql);

			java.sql.Date sqlMfd = new java.sql.Date(product.getManufacturing_date().getTime());
			java.sql.Date sqlExp = new java.sql.Date(product.getExpiry_date().getTime());

			psmt.setString(1, product.getProductName());
			psmt.setString(2, product.getDescription());
			psmt.setDate(3, sqlMfd);
			psmt.setDate(4, sqlExp);
			psmt.setDouble(5, product.getMax_retail_price());
			psmt.setInt(6, product.getCategory().getCategory_Id());
			psmt.setInt(7, product.getSubCategory().getSub_category_Id());
			psmt.setInt(8, product.getSupplier().getSupplierId());
			psmt.setInt(9, product.getQuantity());
			psmt.executeUpdate();

			rs = getPreparedStatement("select * from product").executeQuery();
			while (rs.next()) {
				proId = rs.getInt(1);
			}
			pst = getPreparedStatement("insert into product_discount values(?,?)");
			for (Discount d : getAllDiscounts()) {
				pst.setInt(1, proId);
				pst.setInt(2, d.getDiscountId());
				pst.executeUpdate();
			}

		}

		catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return true;
	}

	public PreparedStatement getPreparedStatement(String query) {
		PreparedStatement psmt = null;
		try {
			psmt = getConnection().prepareStatement(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return psmt;
	}

	public Connection getConnection() {

		try {

			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/classroom", "root", "India123");

		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}

	public List<Product> getAllProducts() {
		List<Product> listProducts = new ArrayList<Product>();
		Product product = null;
		Category category = null;
		SubCategory subcategory = null;
		Supplier supplier = null;
		Discount discount = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		try {
			rs = getPreparedStatement("select * from product").executeQuery();
			while (rs.next()) {
				product = new Product();
				product.setProductId(rs.getInt(1));
				product.setProductName(rs.getString(2));
				product.setDescription(rs.getString(3));
				product.setManufacturing_date(rs.getDate(4));
				product.setExpiry_date(rs.getDate(5));
				product.setMax_retail_price(rs.getDouble(6));

				
				int catId = rs.getInt(7);
				System.out.println("RS:" +rs.getInt(8));
				for (Category cat : getAllCategory()) {
					if (cat.getCategory_Id() == catId) {
						
						category = cat;
						break;
					}
				}
				
				product.setCategory(category);

				// product.setCategory(category);

				int subcatId = rs.getInt(8);
				for (SubCategory subcat : getAllSubCategory()) {
					if (subcat.getSub_category_Id() == subcatId) {
						subcategory = subcat;
						break;
					}

				}

				product.setSubCategory(subcategory);

				int supId = rs.getInt(9);
				for (Supplier supply : getAllSuppliers()) {
					if (supply.getSupplierId() == supId) {
						supplier = supply;
						break;
					}

				}

				product.setSupplier(supplier);
				
				product.setQuantity(rs.getInt(10));

				Discount disount = null;
				List<Discount> discountList = null;
				while (rs.next()) {
					discountList = new ArrayList<Discount>();
					int d = rs.getInt(1);

					for (Discount dis : getAllDiscounts()) {

						if (d == dis.getDiscountId()) {
							discount = dis;
							discountList.add(disount);
						}
					}

				}
				product.setDiscounts(discountList);

				listProducts.add(product);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return listProducts;
	}

	public boolean removeProduct(int product_Id) {
		PreparedStatement psmt1 = getPreparedStatement("Delete from product where product_Id=?");
		PreparedStatement psmt2 = getPreparedStatement("Delete from product_discount where product_Id=?");
		try {
			psmt1.setInt(1, product_Id);
			psmt2.setInt(1, product_Id);
			psmt2.executeUpdate();
			psmt1.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return true;
	}

	public boolean updateProductName(Product uproduct, String name) {
		 PreparedStatement psmt=getPreparedStatement("update product set product_Name=? where product_Id=?");
		 try{
			 psmt.setString(1, name);
			 psmt.setInt(2, uproduct.getProductId());
			 psmt.executeUpdate();
			 }
		 catch(SQLException e)
		 {
			 e.printStackTrace();
		 }
		 finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}

	public boolean updateProductPrice(Product uproduct, double price) {
		 
		 PreparedStatement psmt=getPreparedStatement("update product set MaximumRetailPrice=? where product_Id=?");
		 try{
			 psmt.setDouble(1, price);
			 psmt.setInt(2, uproduct.getProductId());
			 psmt.executeUpdate();
			 }
		 catch(SQLException e)
		 {
			 e.printStackTrace();
		 }
		 finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}

	public boolean updateProductDescription(Product uproduct, String description) {
		 
		 PreparedStatement psmt=getPreparedStatement("update product set description=? where product_Id=?");
		 try{
			 psmt.setString(1, description);
			 psmt.setInt(2, uproduct.getProductId());
			 psmt.executeUpdate();
			 }
		 catch(SQLException e)
		 {
			 e.printStackTrace();
		 }
		 finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}

	/*
	 * //Central Repositary Map<Integer, Product> products=new HashMap<Integer,
	 * Product>();
	 * 
	 * 
	 * public List<Category> getAllCategory() {
	 * 
	 * List<Category> categories=new ArrayList<Category>(); categories.add(new
	 * Category(1, "Electronics", "Electronic Items")); categories.add(new
	 * Category(2, "Clothing", "All Cloth Varity")); categories.add(new
	 * Category(3, "Health&Care", "Health And Hospitality")); categories.add(new
	 * Category(4, "HouseHolds", "HouseHold Items")); categories.add(new
	 * Category(5, "Sports", "Games related Items"));
	 * 
	 * return categories; }
	 * 
	 * public List<SubCategory> getAllSubCategory() {
	 * 
	 * List<SubCategory> subcategories=new ArrayList<SubCategory>();
	 * subcategories.add(new SubCategory(101, "Mobile",new Category(1,
	 * "Electronics", "Electronic Items"))); subcategories.add(new
	 * SubCategory(102, "PowerBank",new Category(1, "Electronics",
	 * "Electronic Items"))); subcategories.add(new SubCategory(103,
	 * "Data Storage",new Category(1, "Electronics", "Electronic Items")));
	 * 
	 * 
	 * subcategories.add(new SubCategory(201, "T-Shirt",new Category(2,
	 * "Clothing", "All Cloth Varity"))); subcategories.add(new SubCategory(202,
	 * "Kurta",new Category(2, "Clothing", "All Cloth Varity")));
	 * subcategories.add(new SubCategory(203, "Saree",new Category(2,
	 * "Clothing", "All Cloth Varity"))); subcategories.add(new SubCategory(204,
	 * "Kids Wear",new Category(2, "Clothing", "All Cloth Varity")));
	 * 
	 * subcategories.add(new SubCategory(301,"Diabetic Shoes",new Category(3,
	 * "Health&Care", "Health And Hospitality"))); subcategories.add(new
	 * SubCategory(302,"Diabetic Metre",new Category(3, "Health&Care",
	 * "Health And Hospitality"))); subcategories.add(new SubCategory(303,
	 * "Blood Pressure Metre",new Category(3, "Health&Care",
	 * "Health And Hospitality")));
	 * 
	 * 
	 * subcategories.add(new SubCategory(401,"Dining Sets", new Category(4,
	 * "HouseHolds", "HouseHold Items"))); subcategories.add(new
	 * SubCategory(402,"Cooker", new Category(4, "HouseHolds", "HouseHold Items"
	 * ))); subcategories.add(new SubCategory(403,"Knife", new Category(4,
	 * "HouseHolds", "HouseHold Items"))); subcategories.add(new
	 * SubCategory(404,"Glasses", new Category(4, "HouseHolds",
	 * "HouseHold Items")));
	 * 
	 * 
	 * subcategories.add(new SubCategory(501, "Cricket Bat", new Category(5,
	 * "Sports", "Games related Items"))); subcategories.add(new
	 * SubCategory(502, "Cricket Ball", new Category(5, "Sports",
	 * "Games related Items"))); subcategories.add(new SubCategory(503,
	 * "Hockey bat", new Category(5, "Sports", "Games related Items")));
	 * subcategories.add(new SubCategory(504, "Hockey Ball", new Category(5,
	 * "Sports", "Games related Items"))); subcategories.add(new
	 * SubCategory(505, "Volley Ball", new Category(5, "Sports",
	 * "Games related Items")));
	 * 
	 * return subcategories; }
	 * 
	 * public List<Supplier> getAllSuppliers() {
	 * 
	 * List<Supplier> suppliers=new ArrayList<Supplier>(); suppliers.add(new
	 * Supplier(111, "Tom", "Jerry", "North Avvenue", "Chennai", "Tamil Nadu",
	 * "600041", "6576575")); suppliers.add(new Supplier(222, "Jack", "Thomson",
	 * "South Avvenue", "Chennai", "Tamil Nadu", "600341", "78987978"));
	 * suppliers.add(new Supplier(333, "Kamal", "Emi", "West Avvenue",
	 * "Chennai", "Tamil Nadu", "600001", "787665765")); suppliers.add(new
	 * Supplier(444, "Annie", "Kenn", "EAST Avvenue", "Pune", "Maharastra",
	 * "600121", "5464565645")); suppliers.add(new Supplier(555, "Vimal",
	 * "Desai", "7th Avvenue", "Pune", "Maharastra", "600121", "87686787"));
	 * suppliers.add(new Supplier(666, "Bimal", "Singh", "12th Avvenue", "Pune",
	 * "Maharastra", "600121", "12456767")); return suppliers; }
	 * 
	 * public List<Discount> getAllDiscounts() { List<Discount> discounts=new
	 * ArrayList<Discount>(); discounts.add(new Discount(123, "Mega Offer",
	 * "Mega offer From Jan to Feb", 12.4, new Date(2009-1900, 4, 23)));
	 * discounts.add(new Discount(333, "Dewali Offer", "Dewali offer ", 12.4,
	 * new Date(2018-1900, 4, 23))); discounts.add(new Discount(678,
	 * "New Year Offer", "New Year offer ", .50, new Date(2020-1900, 4, 23)));
	 * discounts.add(new Discount(1234, "X'Mas Offer", "Xmas offer ", .55, new
	 * Date(2019-1900, 4, 23))); discounts.add(new Discount(340, "Pongal Offer",
	 * "Pongal offer ", 12.78, new Date(2017-1900, 4, 23)));
	 * 
	 * 
	 * return discounts; }
	 * 
	 * public void addProduct(Product product) {
	 * products.put(product.getProductId(), product); System.out.println(
	 * "Product Registered");
	 * 
	 * }
	 * 
	 * public Map<Integer, Product> getAllProducts() {
	 * 
	 * return products; }
	 */

}
