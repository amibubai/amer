package com.flp.pms.dao;

import java.util.List;
import java.util.Map;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;

public interface IProductDao {
	
	public List<Category> getAllCategory();
	public List<SubCategory> getAllSubCategory();
	public List<Supplier> getAllSuppliers();
	public List<Discount> getAllDiscounts();
	
	public boolean addProduct(Product product);
	 
	public boolean removeProduct(int i);
	
	public  List<Product> getAllProducts();
	public boolean updateProductName(Product uproduct,String name);
	public boolean updateProductPrice(Product uproduct,double price);
	public boolean updateProductDescription(Product uproduct,String name);
	

}
