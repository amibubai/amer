package com.flp.pms.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImp;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.flp.pms.util.Validate;

public class ProductServiceImpl implements IProductService {

	private IProductDao iProductDao = new ProductDaoImp();

	public List<Category> getAllCategory() {
		return iProductDao.getAllCategory();
	}

	public List<SubCategory> getAllSubCategory() {
		return iProductDao.getAllSubCategory();
	}

	public List<Discount> getAllDiscounts() {

		return iProductDao.getAllDiscounts();
	}

	public List<Supplier> getAllSupplier() {

		return iProductDao.getAllSuppliers();
	}

	public boolean addProduct(Product product) {
		return  iProductDao.addProduct(product);
		
	}
  
	public Product searchProductName(String productName) {
		// TODO Auto-generated method stub
		return null;
	}

	public Product searchProductBySupplier(String supplierName) {
		// TODO Auto-generated method stub
		return null;
	}

	public Product searchProductBySubCategory(String subcatName) {
		// TODO Auto-generated method stub
		return null;
	}

	public Product searchProductByCategory(String catName) {
		// TODO Auto-generated method stub
		return null;
	}

	public Product searchProductByRating(float rating) {
		// TODO Auto-generated method stub
		return null;
	}

	public Product searchProductById(int productId) {
		 List<Product>products=getAllProducts();
		 Product searchProduct=null;
		 for (Product product : products) {
			 if(product.getProductId()==productId)
				 searchProduct=product;
			
		}
		return searchProduct;
	}
 

	public List<Product> getAllProducts() {
	 
		List<Product> listProducts = new ArrayList<Product>();
		listProducts= iProductDao.getAllProducts();
		return listProducts; 
		 
	}

	 

	public boolean delectProduct(int productId) {
		 
		return iProductDao.removeProduct(productId);
	}

	public boolean updateProductName(Product uproduct, String name) {
		 
		return iProductDao.updateProductName(uproduct, name);
	}

	public boolean updateProductPrice(Product uproduct, double price) {
		 
		return  iProductDao.updateProductPrice(uproduct, price);
	}

	public boolean updateProductDescription(Product uproduct, String name) {
		 
		return iProductDao.updateProductDescription(uproduct, name);
	}

	 
}
