package com.flp.pms.service;

import java.util.List;
import java.util.Map;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;

public interface IProductService {
	public List<Category> getAllCategory();
	public List<SubCategory> getAllSubCategory();
	public List<Discount> getAllDiscounts();
	public List<Supplier> getAllSupplier();
	
	public boolean addProduct(Product product);
	public boolean delectProduct(int productId);
	
	
	
	
	public List<Product> getAllProducts();
	public Product searchProductName(String productName);
	public Product searchProductBySupplier(String supplierName);
	public Product searchProductBySubCategory( String subcatName);
	public Product searchProductByCategory(String catName);
	public Product searchProductByRating(float rating);
	public Product searchProductById(int productId);
	public boolean updateProductName(Product uproduct,String name);
	public boolean updateProductPrice(Product uproduct,double price);
	public boolean updateProductDescription(Product uproduct,String name);
 
	 
}
